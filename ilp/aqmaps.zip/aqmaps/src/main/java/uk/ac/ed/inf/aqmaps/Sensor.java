package uk.ac.ed.inf.aqmaps;

import com.mapbox.geojson.Point;

public class Sensor {
	//What3words address of the sensor
	private String word3address;
	
	//Reading of the sensor
	private double reading;
	
	//Coordinate location of the sensor
	private Point location;
	
	public Sensor(String address,double reading,Point location) {
		this.word3address=address;
		this.reading=reading;
		this.location=location;
	}
	public Point getLocation() {
		return location;
	}
	public double getReading() {
		return reading;
	}
	public String getAddress() {
		return word3address;
	}
}

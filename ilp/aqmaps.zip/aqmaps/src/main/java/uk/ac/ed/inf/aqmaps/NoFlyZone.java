package uk.ac.ed.inf.aqmaps;

import com.mapbox.geojson.*;
import java.util.List;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.awt.geom.Line2D;

public class NoFlyZone{
	private static final HttpClient client = HttpClient.newHttpClient();
	
	//Four polygons of no-fly-zones
	private List<Polygon> zones=new ArrayList<>();
	
	public NoFlyZone(int port) throws IOException, InterruptedException {
		//Acquire data of no-fly-zones from the server
		String path="http://localhost:"+String.valueOf(port)+"/buildings/no-fly-zones.geojson";
		HttpRequest request = (HttpRequest) HttpRequest.newBuilder()
				.uri(URI.create(path))
				.build();
		HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
		String line=response.body();
		FeatureCollection noFlyZone=FeatureCollection.fromJson(line);
		
		//Store into the list
		for(Feature f:noFlyZone.features()) {	
			Polygon p=(Polygon) f.geometry();
			zones.add(p);
		}
	}
	
	//Check whether the line segment joining "start" and "end" intersects with
	//the line segment joining "p1" and "p2"
	public boolean checkIntersect(Point start,Point end,Point p1,Point p2) {
		//returns true if there is no intersection
		double x1=start.longitude();
		double y1=start.latitude();
		double x2=end.longitude();
		double y2=end.latitude();
		double x3=p1.longitude();
		double y3=p1.latitude();
		double x4=p2.longitude();
		double y4=p2.latitude();
		Line2D line1=new Line2D.Double(x1,y1,x2,y2);
		Line2D line2=new Line2D.Double(x3,y3,x4,y4);
		return !line1.intersectsLine(line2);
	}
	
	//Check against all edges of no-fly-zones
	public boolean checkNoFlyZone(AStarPoint starta,AStarPoint enda) {
		//returns true if does not cross no-fly-zones
		Point start=Point.fromLngLat(starta.longitude(), starta.latitude());
		Point end=Point.fromLngLat(enda.longitude(), enda.latitude());
		for(Polygon p:zones) {
			List<Point> points=p.coordinates().get(0);
			for(int i=0;i<points.size()-1;i++) {
				Point p1=points.get(i);
				Point p2=points.get(i+1);
				if(!checkIntersect(start,end,p1,p2)) {
					return false;
				}
			}
		}
		return true;
	}
	public List<Polygon> getZones(){
		return zones;
	}
}

package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.mapbox.geojson.*;

public class Generator {
	//List of points that the drone passes for the entire journey
	protected List<Point> flightpaths=new ArrayList<>();
	
	//Angle the drone flies in each time
	protected List<Integer> directions=new ArrayList<>();
	
	//Sensor visited in the order determined by "perm"
	protected List<Sensor> sensorspath=new ArrayList<>();
	
	//Nearest sensor after each move
	protected List<Sensor> total_sensorspath=new ArrayList<>();
	
	//Number of sensors
	protected int n=0;
	
	public Generator(int port,int yy,int mm,int dd,Point start) throws IOException, InterruptedException {
		SensorCollection sc=new SensorCollection(port,yy,mm,dd);
		List<Sensor> sensors=sc.getSensors();
		List<Point> coordinates=new ArrayList<>();
		n=sensors.size();
		for(Sensor s:sensors) {
			coordinates.add(s.getLocation());
		}
		Sequence ss=new Sequence(coordinates);
		int[] perm=ss.getPerm();
		double min_distance=Double.MAX_VALUE;
		int start_idx=0;
		
		//Find the sensor closest to starting point and its index
		for(int i=0;i<n;i++) {
			double distance=euclidDistance(start,coordinates.get(i));
			if(distance<min_distance) {
				min_distance=distance;
				start_idx=i;
			}
		}
		
		//Find the index of the that sensor in perm 
		int start_perm_idx=0;
		for(int i=0;i<n;i++) {
			if(perm[i]==start_idx) {
				start_perm_idx=i;
			}
		}
		
		//Add the sensors to "sensorspath" with the same order in "perm" but different start
		for(int i=0;i<n;i++) {
			sensorspath.add(sensors.get(perm[(start_perm_idx+i)%n]));
		}
		generatePaths(port,start);
		setDirections(flightpaths);
	}
	
	//Find the Euclidean distance between two points
	public double euclidDistance(Point p1,Point p2) {
		return Math.sqrt(Math.pow(p1.longitude()-p2.longitude(),2)+
				Math.pow(p1.latitude()-p2.latitude(),2));
	}
	
	//Compute "flightpaths" where the drone passes through sensors one by one and
	//returns to its starting position. Compute the "total_sensorspath" at the same time
	public void generatePaths(int port,Point start) throws IOException, InterruptedException {
		//Firstly, the drone has to fly from the starting point to the first sensor
		List<Point> path=new ArrayList<>();
		List<Point> result=new ArrayList<>();
		AStarSearch search=new AStarSearch(port);
		Point first=sensorspath.get(0).getLocation();
		AStarPoint afirst=new AStarPoint(first.longitude(),first.latitude());
		AStarPoint astart=new AStarPoint(start.longitude(),start.latitude());
		path=search.findPath(astart,afirst);
		result.addAll(path);
		result.remove(result.size()-1);
		//There will be updates in "total_sensorspath" only if the drone makes a move
		if(path.size()>1) {
			for(int j=1;j<path.size();j++) {
				if(j==path.size()-1) {
					total_sensorspath.add(sensorspath.get(0));
				}
				else total_sensorspath.add((Sensor)null);
			}
		}
		
		//Make a loop as the drone flies from one sensor to another
		for(int i=1;i<n;i++) {
			Point end_start=path.get(path.size()-1);
			search=new AStarSearch(port);
			first=sensorspath.get(i).getLocation();
			astart=new AStarPoint(end_start.longitude(),end_start.latitude());
			afirst=new AStarPoint(first.longitude(),first.latitude());
			path=search.findPath(astart,afirst);
			result.addAll(path);
			result.remove(result.size()-1);
			if(path.size()>1) {
				for(int j=1;j<path.size();j++) {
					if(j==path.size()-1) {
						total_sensorspath.add(sensorspath.get(i));
					}
					else total_sensorspath.add((Sensor)null);
				}
			}
		}
		
		//Lastly, find the path for the drone to return to its starting position.
		Point end_start=path.get(path.size()-1);
		search=new AStarSearch(port);
		first=start;
		astart=new AStarPoint(end_start.longitude(),end_start.latitude());
		afirst=new AStarPoint(first.longitude(),first.latitude());
		path=search.findPath(astart,afirst);
		result.addAll(path);
		if(path.size()>1) {
			for(int j=1;j<path.size();j++) {
				if(j==path.size()-1) {
					total_sensorspath.add(sensorspath.get(0));
				}
				else total_sensorspath.add((Sensor)null);
			}
		}
		flightpaths=result;
	}
	public List<Sensor> getTotalSensorPaths(){
		return total_sensorspath;
	}
	public List<Point> getFlightpaths(){
		return flightpaths;
	}
	
	//Calculate the angle the drone flies in. Result is from 0 to 350 degrees.
	public void setDirections(List<Point> path) {
		for(int i=0;i<path.size()-1;i++) {
			Point a=path.get(i);
			Point b=path.get(i+1);
			int atan2=Math.round((float)Math.toDegrees(Math.atan2(b.latitude()-a.latitude(),b.longitude()-a.longitude())));
			if(atan2<0) {
				atan2+=360;
			}
			directions.add(atan2);
		}
	}
}

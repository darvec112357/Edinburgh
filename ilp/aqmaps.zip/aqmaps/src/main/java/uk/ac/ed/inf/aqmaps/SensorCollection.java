package uk.ac.ed.inf.aqmaps;

import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import com.mapbox.geojson.*;

public class SensorCollection {
	private static final HttpClient client = HttpClient.newHttpClient();
	
	//List of sensors to be visited
	private List<Sensor> sensors=new ArrayList<>();
	
	public SensorCollection(int port,int yy,int mm,int dd) throws IOException, InterruptedException {
		//First acquire the sensors to be visited on the given date
		String d="";
		String m="";
		d=dd<10 ? "0"+String.valueOf(dd) : String.valueOf(dd);
		m=mm<10 ? "0"+String.valueOf(mm) : String.valueOf(mm);
		String path="http://localhost:"+String.valueOf(port)+"/maps"+
				"/"+String.valueOf(yy)+"/"+m+"/"+d+"/air-quality-data.json";
		JsonElement json = getJson(path);
		JsonArray array=json.getAsJsonArray();
		for(int i=0;i<33;i++) {
			JsonObject object=array.get(i).getAsJsonObject();
			path="http://localhost:"+String.valueOf(port)+"/words";
			String address=object.get("location").getAsString();
			double reading=0;
			
			//If the battery is below 10%, the reading should not be taken, so just record as -1.
			if(object.get("battery").getAsDouble()<10) {
				reading=-1;
			}
			else reading=object.get("reading").getAsDouble();
			
			//Use the word3address to get the path and get the details of each sensor on server 
			for(String word:address.split("\\.")) {
				path+="/"+word;
			}
			path+="/details.json";
			JsonObject details = getJson(path).getAsJsonObject();
			double longitude=details.get("coordinates").getAsJsonObject().get("lng").getAsDouble();
			double latitude=details.get("coordinates").getAsJsonObject().get("lat").getAsDouble();
			Point p=Point.fromLngLat(longitude, latitude);
			Sensor sensor=new Sensor(address,reading,p);
			sensors.add(sensor);
		}
	}
	
	//Acquire data from server using "path" as the website
	public JsonElement getJson(String path) throws IOException, InterruptedException {
		HttpRequest request = (HttpRequest) HttpRequest.newBuilder()
				.uri(URI.create(path))
				.build();
		HttpResponse<String> response = client.send(request, BodyHandlers.ofString()); 
		JsonElement json = JsonParser.parseString(response.body());
		return json;
	}
	public List<Sensor> getSensors(){
		return sensors;
	}
	public static void main(String[] args) throws IOException, InterruptedException {

	}
}

package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import com.mapbox.geojson.*;

public class AStarSearch {
	//Used for checking no-fly-zones when finding the path
	private NoFlyZone noflyzones;
	
	//Quota of the PriorityQueue
	private static final int cutoff=500000;
	
	public AStarSearch(int port) throws IOException, InterruptedException{
		noflyzones=new NoFlyZone(port);
	}
	
	//Find the Euclidean distance between two points
	public double euclidDistance(AStarPoint p1,AStarPoint p2) {
		return Math.sqrt(Math.pow(p1.longitude()-p2.longitude(),2)+
				Math.pow(p1.latitude()-p2.latitude(),2));
	}
	
	//Check whether the point is within 0.0002 degree of the goal
	public boolean inRange(AStarPoint p,AStarPoint goal) {
		return euclidDistance(p,goal)<=0.0002;
	}
	
	//Find a path from "start" to "end" using A* search algorithm
	public List<Point> findPath(AStarPoint start,AStarPoint end){
		//Candidate of the points that can be used to form the path
		PriorityQueue<AStarPoint> OpenSet=new PriorityQueue<>(new ComparePoints());
		start.setG(0);
		OpenSet.add(start);
		AStarPoint best=null;
		while(!OpenSet.isEmpty()) {
			
			//Get the current best candidate
			AStarPoint current=OpenSet.poll();
			
			//Update the best candidate
			if(best==null||best.getG()<current.getG()) {
				best=current;
			}
			
			//If we have reached the target, we can return the path.
			if(inRange(current,end)) {
				return constructPath(current);
			}
			
			//If we have reached the quota of the PriorityQueue, but have not reached the target yet,
			//we use the best candidate as our intermediate point and concatenate the two paths together
			if(OpenSet.size()>cutoff) {
				List<Point> part=constructPath(best);
				part.remove(part.size()-1);
				best.setPrevious(null);
				part.addAll(findPath(best,end));
				return part;
			}
			
			List<AStarPoint> neighbors=current.getNeighbors();
			for(AStarPoint neighbor:neighbors) {
				if(noflyzones.checkNoFlyZone(current,neighbor)) {
					//As long as the flight from "current" to "neighbor" does not cross no-fly-zones,
					//we will update its relevant details and add it to the queue
					double tempg=current.getG()+0.0003;
					double tempf=tempg+euclidDistance(neighbor,end);
					neighbor.setG(tempg);
					neighbor.setF(tempf);
					OpenSet.add(neighbor);
					neighbor.setPrevious(current);
				}
			}
		}
		return null;
	}
	
	//Find the path all the way till point p
	public List<Point> constructPath(AStarPoint p){
		List<Point> result=new ArrayList<>();
		AStarPoint temp=p;
		result.add(Point.fromLngLat(temp.longitude(),temp.latitude()));
		//We start from p and backtrack.
		while(temp.getPrevious()!=null) {
			AStarPoint previous=temp.getPrevious();
			result.add(Point.fromLngLat(previous.longitude(), previous.latitude()));
			temp=temp.getPrevious();
		}
		//We need to reverse the result to get a path with p as the end point
		Collections.reverse(result);
		return result;
	}
}

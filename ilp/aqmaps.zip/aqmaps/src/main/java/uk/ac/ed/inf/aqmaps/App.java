package uk.ac.ed.inf.aqmaps;

import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import com.mapbox.geojson.*;

public class App extends Generator{
	public App(int port,int yy,int mm,int dd,Point start) throws IOException, InterruptedException {
		super(port,yy,mm,dd,start);
	}
	
	//Get the color corresponding to the reading,expressed as a rgb-string
	public String getColor(double n) {
		if(0<=n&&n<32) {
			return "#00ff00";
		}
		if(32<=n&&n<64) {
			return "#40ff00";
		}
		if(64<=n&&n<96) {
			return "#80ff00";
		}
		if(96<=n&&n<128) {
			return "#c0ff00";
		}
		if(128<=n&&n<160) {
			return "#f0ff00";
		}
		if(160<=n&&n<192) {
			return "#ffc000";
		}
		if(192<=n&&n<224) {
			return "#ff8000";
		}
		if(224<=n&&n<256) {
			return "#ff4000";
		}
		
		//For the case of -1 (low battery)
		return "000000";
	}
	
	//Get the marker symbol corresponding to the predicted value
	public String getSymbol(double n) {
		if(0<=n&&n<128) {
			return "lighthouse";
		}
		if(128<=n&&n<256) {
			return "danger";
		}
		
		//For the case of -1 (low battery)
		return "cross";
	}
	
	//Generate the required text file on the given date
	public void generateText(int yy,int mm,int dd){
		String text="";
		for(int i=0;i<total_sensorspath.size();i++) {
			if(total_sensorspath.get(i)!=null) {
				//If there is indeed a sensor nearby, we write its word3address
				Point location=flightpaths.get(i);
				Point location2=flightpaths.get(i+1);
				text+=String.valueOf(i+1)+","+String.valueOf(location.longitude())+","+String.valueOf(location.latitude())+",";
				text+=String.valueOf(directions.get(i))+",";
				text+=String.valueOf(location2.longitude())+","+String.valueOf(location2.latitude())+",";
				text+=total_sensorspath.get(i).getAddress();
				text+="\n";
			}
			else {
				//If there is no sensor nearby, we record "null" as required
				Point location=flightpaths.get(i);
				Point location2=flightpaths.get(i+1);
				text+=String.valueOf(i+1)+","+String.valueOf(location.longitude())+","+String.valueOf(location.latitude())+",";
				text+=String.valueOf(directions.get(i))+",";
				text+=String.valueOf(location2.longitude())+","+String.valueOf(location2.latitude())+",";
				text+="null";
				text+="\n";
			}
		}
		String d="";
		String m="";
		d=dd<10 ? "0"+String.valueOf(dd) : String.valueOf(dd);
		m=mm<10 ? "0"+String.valueOf(mm) : String.valueOf(mm);
		String path="flightpath-"+d+"-"+m+"-"+String.valueOf(yy)+".txt";
		try {
    		BufferedWriter out=new BufferedWriter(new FileWriter(path));
            out.write(text);
            out.close();
        } catch (IOException e) {}
	}
	
	//Generate the required geojson file
	public void generateJson(int yy,int mm,int dd) {
		//The line string is the outline of the flight path.
		LineString line=LineString.fromLngLats(flightpaths);
		Feature f=Feature.fromGeometry(line);
		List<Feature> features=new ArrayList<>();
		features.add(f);
		for(int i=0;i<n;i++) {
			Sensor sensor=sensorspath.get(i);
			
			//Create the feature using the location of the sensor as the geometry (Point)
			Feature fi=Feature.fromGeometry(sensor.getLocation());
			
			//Set the relevant properties
			fi.addStringProperty("location",sensor.getAddress());
			fi.addStringProperty("rgb-string", getColor(sensor.getReading()));
			fi.addStringProperty("marker-symbol", getSymbol(sensor.getReading()));
			fi.addStringProperty("marker-color", getColor(sensor.getReading()));
			features.add(fi);
		}
		
		//Form a FeatureCollection and generate its json document.
		FeatureCollection result=FeatureCollection.fromFeatures(features);
    	String json=result.toJson();
		String d="";
		String m="";
		d=dd<10 ? "0"+String.valueOf(dd) : String.valueOf(dd);
		m=mm<10 ? "0"+String.valueOf(mm) : String.valueOf(mm);
		String path="readings-"+d+"-"+m+"-"+String.valueOf(yy)+".geojson";
		try {
    		BufferedWriter out=new BufferedWriter(new FileWriter(path));
            out.write(json);
            out.close();
        } catch (IOException e) {}
	}
	
    public static void main(String[] args) throws Exception{
        int dd=Integer.parseInt(args[0]);
        int mm=Integer.parseInt(args[1]);
        int yy=Integer.parseInt(args[2]);
        double lat=Double.parseDouble(args[3]);
        double lng=Double.parseDouble(args[4]);
        int port=Integer.parseInt(args[6]);
        Point start=Point.fromLngLat(lng, lat);
        App app=new App(port,yy,mm,dd,start);
        app.generateText(yy,mm,dd);
        app.generateJson(yy,mm,dd);
    }
}

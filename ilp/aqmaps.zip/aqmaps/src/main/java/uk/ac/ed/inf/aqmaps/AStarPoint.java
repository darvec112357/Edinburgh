package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;

public class AStarPoint {
	//Base angle drone turns in
	private final double theta=Math.toRadians(10);
	
	//Longitude of the drone
	private double longitude;
	
	//Latitude of the drone
	private double latitude;
	
	//f value of the point
	private double f=0;
	
	//g value of the point
	private double g=0;
	
	//Preceding point to form the shortest path
	private AStarPoint previous;
	
	public AStarPoint(double lng,double lat) {
		longitude=lng;
		latitude=lat;
	}
	public double getG() {
		return g;
	}
	public void setG(double value) {
		g=value;
	}
	public double getF() {
		return f;
	}
	public void setF(double value) {
		f=value;
	}
	public double longitude() {
		return longitude;
	}
	public double latitude() {
		return latitude;
	}
	public AStarPoint getPrevious() {
		return previous;
	}
	public void setPrevious(AStarPoint p) {
		previous=p;
	}
	
	//Create a list of the 36 neighbors of the point
	public List<AStarPoint> getNeighbors(){
		List<AStarPoint> answer=new ArrayList<>();
		for(int i=0;i<36;i++) {
			double newlng=longitude+0.0003*Math.cos(theta*i);
			double newlat=latitude+0.0003*Math.sin(theta*i);
			AStarPoint a=new AStarPoint(newlng,newlat);
			//Since the distance is 0.0003, g value is increased by 0.0003
			a.setG(getG()+0.0003);
			answer.add(a);
		}
		return answer;
	}
}

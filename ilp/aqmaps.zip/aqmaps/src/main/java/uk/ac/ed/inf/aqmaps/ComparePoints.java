package uk.ac.ed.inf.aqmaps;

import java.util.Comparator;

public class ComparePoints implements Comparator<AStarPoint>{
	@Override
	//We order AStarPoint by comparing their f values, which will be used in PriorityQueue.
	public int compare(AStarPoint a, AStarPoint b) {
		if(a.getF()<b.getF()) {
			return -1;
		}
		else if(a.getF()==b.getF()) {
			return 0;
		}
		return 1;
	}
}

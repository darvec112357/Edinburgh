package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import java.util.List;

import com.mapbox.geojson.Point;

public class Sequence {
	//Coordinates of sensors
	private List<Point> coordinates=new ArrayList<>();
	
	//Number of sensors
	private int n=0;
	
	//Distance between sensors
	private double[][] distance;
	
	//Optimal permutation of sensors to visit
	private int[] perm;
	
	public Sequence(List<Point> points) {
		coordinates=points;
		n=coordinates.size();
		distance=new double[coordinates.size()][coordinates.size()];
		perm=new int[coordinates.size()];
		SetDistance();
		for(int i=0;i<n;i++) {
			perm[i]=i;
		}
		
		//Perform two heuristics to get the optimal permutation
		SwapHeuristic();
		ReverseHeuristic();
	}
	
	//Calculate the distance between each pair of coordinates
	public void SetDistance() {
		for(int i=0;i<n;i++) {
			distance[i][i]=0;
			Point p1=coordinates.get(i);
			for(int j=0;j<n;j++) {
				Point p2=coordinates.get(j);
				distance[i][j]=Math.sqrt(Math.pow(p1.longitude()-p2.longitude(),2)+
						Math.pow(p1.latitude()-p2.latitude(),2));
			}
		}
	}
	
	//Prevent occurence of negative number by converting it to its modulo
	public int mod(int i,int mod) {
		while(i<0) {
			i+=mod;
		}
		return i;
	}
	
	//Try to swap the sequence of the i^th point and the (i+1)%n^th point in the permutation
	public boolean trySwap(int i) {
		//Sum of distances of the (i,i-1) and (i+1,i+2) before the swap
		//After the swap, the only change is that we have the sum of distances of
		//(i-1,i+1) and (i,i+2) instead. Hence, we just need to compare the two sums
		//without having to check the entire sum of distances
		double previous=distance[perm[(i+1)%n]][perm[(i+2)%n]]+distance[perm[mod(i-1,n)]][perm[i]];
		double trial=distance[perm[i]][perm[(i+2)%n]]+distance[perm[mod(i-1,n)]][perm[(i+1)%n]];
		if(trial<previous) {
			//If the sum of distances is smaller, we have found a better permutation
			//and we apply the swap.
			int a=perm[i];
			perm[i]=perm[(i+1)%n];
			perm[(i+1)%n]=a;
			return true;
		}
		else return false;
	}
	
	//Reverse the order of elements from "start" to "end" in current permutation
	public void reverse(int start,int end) {
		int a=end-start;
		for(int i=0;i<=a/2;i++) {
			int b=perm[start+i];
			perm[start+i]=perm[end-i];
			perm[end-i]=b;
		}
	}
	
	//Try reverse the order of elements from i to j
	public boolean tryReverse(int start,int end) {
		//Sum of distances of the (start,start-1) and (end,end+1) before the reversal
		//After the reversal, the only change is that we have the sum of distances of
		//(start-1,end) and (start,end+1) instead. Hence, we just need to compare the two sums
		//without having to check the entire sum of distances
		double previous=distance[perm[mod(start-1,n)]][perm[start]]+distance[perm[end]][perm[(end+1)%n]];
		double trial=distance[perm[mod(start-1,n)]][perm[end]]+distance[perm[start]][perm[(end+1)%n]];
		if(trial<previous) {
			//If the sum of distances is smaller, we have found a better permutation
			//and we apply the reversal.
			reverse(start,end);
			return true;
		}
		else return false;
	}
	
	//Repeatedly trySwap
	public void SwapHeuristic() {
		boolean better=true;
		while(better) {
			better=false;
			for(int i=0;i<n;i++) {
				if(trySwap(i)) {
					//This means that we have found a better permutation,
					//so we have to start a new loop. If not then we are finished.
					better=true;
				}
			}
		}
	}
	
	//Repeatedly tryReverse
	public void ReverseHeuristic() {
		boolean better=true;
		while(better) {
			better=false;
			for(int j=0;j<n-1;j++) {
				for(int i=0;i<j;i++) {
					if(tryReverse(i,j)) {
						//This means that we have found a better permutation,
						//so we have to start a new loop. If not then we are finished.
						better=true;
					}
				}
			}
		}
	}
	public int[] getPerm() {
		return perm;
	}
}
